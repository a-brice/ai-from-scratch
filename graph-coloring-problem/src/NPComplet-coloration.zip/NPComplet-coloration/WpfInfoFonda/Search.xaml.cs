﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Drawing;
using System.IO;

namespace WpfInfoFonda
{
    /// <summary>
    /// Logique d'interaction pour Search.xaml
    /// </summary>
    public partial class Search : Window
    {
        public Search()
        {
            InitializeComponent();
        }
        Dictionary<int, List<Maillon>> dic = null; Lien[] lien; TimeSpan t = new TimeSpan(); int solutionAafficher; // Pour le onclick sur un item de la combobox
        public Search(Dictionary<int, List<Maillon>> dico, Lien[] link, DateTime tempsdebut, int solutionAafficher)
        {
            InitializeComponent();
            main(dico,link, solutionAafficher);

            // Afficher les element du haut de la page
            TimeSpan tempsexecution = DateTime.Now - tempsdebut;
            lbltime.Content +=  $"  {tempsexecution.Minutes} min et {tempsexecution.TotalSeconds.ToString().Substring(0,6)} secondes ";
            nbsol.Content += " "  + dico.Count;
            List<int> lstNbSol = dico.Keys.ToList().FindAll(x => x < 99);
            choixsolution.ItemsSource = lstNbSol;

            // Pour le onclick sur un item de la combobox et le vérificateur
            dic = dico; lien = link; t = tempsexecution;
            this.solutionAafficher = solutionAafficher;

            // Pour le bas (combinaison afficher)
            if (dico.ContainsKey(solutionAafficher))
                dico[solutionAafficher].ForEach(delegate (Maillon x) { txtblockdispo.Text += x + "\n"; });

        }

        public Search(Dictionary<int, List<Maillon>> dico, Lien[] link, TimeSpan tempsexecution, int solutionAafficher)
        {
            InitializeComponent();
            main(dico, link, solutionAafficher);

            // Afficher les element du haut de la page
            lbltime.Content += $"  {tempsexecution.Minutes} min et {tempsexecution.TotalSeconds.ToString().Substring(0, 6)} secondes ";
            nbsol.Content += " " + dico.Count;
            List<int> lstNbSol = dico.Keys.ToList().FindAll(x => x < 99);
            choixsolution.ItemsSource = lstNbSol;

            // Pour le onclick sur un item de la combobox  et le vérificateur
            dic = dico; lien = link; t = tempsexecution;
            this.solutionAafficher = solutionAafficher;


            // Pour le bas (combinaison afficher)
            if (dico.ContainsKey(solutionAafficher))
                dico[solutionAafficher].ForEach(delegate (Maillon x) { txtblockdispo.Text += x + "\n"; });
        }


        public Line CreateLine(Point a, Point b)
        {
            Line line = new Line();
            line.Stroke = System.Windows.Media.Brushes.LightSteelBlue;

            line.X1 = a.X + 20;
            line.X2 = b.X + 20;
            line.Y1 = a.Y + 20;
            line.Y2 = b.Y + 20;

            line.StrokeThickness = 4;
            #region Attribution Couleur
            LinearGradientBrush gradientcolor = new LinearGradientBrush();
            gradientcolor.StartPoint = new System.Windows.Point(0, 0);
            gradientcolor.EndPoint = new System.Windows.Point(1, 1);
            gradientcolor.GradientStops.Add(new GradientStop(Colors.Transparent, 0.05));
            gradientcolor.GradientStops.Add(new GradientStop(Colors.White, 0.1));
            gradientcolor.GradientStops.Add(new GradientStop(Colors.Gray, 0.25));
            gradientcolor.GradientStops.Add(new GradientStop(Colors.Gray, 0.75));
            gradientcolor.GradientStops.Add(new GradientStop(Colors.White, 0.9));
            gradientcolor.GradientStops.Add(new GradientStop(Colors.Transparent, 0.95));
            line.Stroke = gradientcolor;
            #endregion

            return line;
        }

        public void CreateEllipse(double lg, string col, Point p, string id)
        {
            #region couleur des cercle
            System.Windows.Media.Brush color = System.Windows.Media.Brushes.Red;
            switch (col)
            {
                case "Rouge":
                    color = System.Windows.Media.Brushes.Red;
                    break;
                case "Violet":
                    color = System.Windows.Media.Brushes.BlueViolet;
                    break;
                case "Vert":
                    color = System.Windows.Media.Brushes.GreenYellow;
                    break;
                case "Bleue":
                    color = System.Windows.Media.Brushes.Aqua;
                    break;
                case "Orange":
                    color = System.Windows.Media.Brushes.DarkOrange;
                    break;
                default:
                    color = System.Windows.Media.Brushes.Black;
                    break;
            }
            #endregion
            Ellipse circle = new Ellipse()
            {
                Width = lg,
                Height = lg,
                Stroke = color,
                StrokeThickness = 5
            };

            circle.SetValue(Canvas.LeftProperty, p.X);
            circle.SetValue(Canvas.TopProperty, p.Y);
            cv.Children.Add(circle);

            TextBlock text = new TextBlock()
            {
                Text = id,
                FontFamily = new System.Windows.Media.FontFamily("Rockwell Condensed"),
                FontSize = 20
            };
            text.SetValue(Canvas.LeftProperty, p.X + lg / 2.6);
            text.SetValue(Canvas.TopProperty, p.Y + lg / 3.2);
            cv.Children.Add(text);

        }


        public void AjouterLienGraph(Lien[] link, List<Point> lstpoint)
        {
            if (link != null && lstpoint != null && link.Length > 0 && lstpoint.Count > 0)
            {
                for (int i = 0; i < link.Length; i++)
                {
                    int idMaillonA = link[i].A.Id;
                    int idMaillonB = link[i].B.Id;
                    if(lstpoint.Count >= idMaillonA && lstpoint.Count >= idMaillonB)
                    {
                        Line l = CreateLine(lstpoint[idMaillonA - 1], lstpoint[idMaillonB - 1]);
                        cv.Children.Add(l);
                    }
                    
                }
            }
        }

        public void main(Dictionary<int, List<Maillon>> dico, Lien[] link, int solutionAafficher)
        {
           
            List<Point> lstpoint = new List<Point>();
            int ID = 0;
            if (dico.ContainsKey(solutionAafficher))
                
                dico[solutionAafficher].ForEach(x => {
                    System.Threading.Thread.Sleep(10);
                    Random r = new Random();
                    System.Threading.Thread.Sleep(10);
                    Point a = new Point();
                    bool distancesuf = true;
                    do
                    {
                        distancesuf = true;
                        a = new Point(r.Next(0, 690), r.Next(10, 400));
                        foreach (Point point in lstpoint)
                        {
                            if (!Point.DistanceSuffisante(a, point)) distancesuf = false;
                        }

                    } while (lstpoint.Count > 0 && !distancesuf);

                    CreateEllipse(50, x.Couleur, a, /* x.Id.ToString()*/ (++ID).ToString());
                    lstpoint.Add(a);
                });

            AjouterLienGraph(link, lstpoint);

        }
       

        private void Choixsolution_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int.TryParse(choixsolution.SelectedValue.ToString(), out int numsolution);
            Search s = new Search(dic,lien,t ,numsolution);
            s.Show();
        }

        

    }
}
