﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfInfoFonda
{
    public class RetourPoly
    {
        List<Maillon> solveur;
        Lien[] lien;

        public RetourPoly(List<Maillon> solveur, Lien[] lien)
        {
            this.solveur = solveur;
            this.lien = lien;
        }

        public List<Maillon> Solveur
        {
            get { return this.solveur; }
        }
        public Lien[] Lien
        {
            get { return this.lien; }
        }
    }
}
