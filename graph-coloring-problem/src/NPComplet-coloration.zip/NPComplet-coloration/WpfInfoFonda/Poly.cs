﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Forms;
using System.Drawing;
using System.IO;


namespace WpfInfoFonda
{
    public class Poly
    {

        /// <summary>
        /// Détermine toutes les arêtes de la figure contenant le sommet étudié.
        /// </summary>
        /// <param name="som">Sommet étudié.</param>
        /// <param name="aretes">Ensemble des arêtes de la figure.</param>
        /// <returns>Renvoye une matrice de toutes les arêtes contenant le sommet étudié.</returns>
        public static Lien[] AretesSommet(Maillon som, Lien[] liens)
        {
            Lien[] aretessom = new Lien[liens.Length];
            int count = 0;
            for (int i = 0; i < liens.Length; i++)
            {
                if (liens[i].A == som || liens[i].B == som)
                {
                    aretessom[count] = liens[i];
                    count++;
                }
            }
            return aretessom;
        }

        /// <summary>
        /// Renvoye un tableau de bool indiquant si le sommet peut être colorié en bleu, en rouge ou en jaune. Le nom des couleurs change en fonction des couleurs contenues dans color.
        /// </summary>
        /// <param name="som">Sommet étudié.</param>
        /// <param name="aretessom">Ensemble des arêtes contenant le sommet étudié.</param>
        /// <param name="color">Palette de couleurs utilisées.</param>
        /// <returns>Le tableau de booléens renvoyé est de la forme [bleu, rouge, jaune].</returns>
        static bool[] WhichColor(Maillon som, Lien[] liens, String[] color)
        {
            bool blue = true;
            bool red = true;
            bool yellow = true;
            bool brown = true;
            for (int i = 0; i < liens.Length; i++)
            {
                if (liens[i] != null && (som == liens[i].A) && (liens[i].B.Couleur != null))
                {
                    if (liens[i].B.Couleur == color[0]) { blue = false; }
                    if (liens[i].B.Couleur == color[1]) { red = false; }
                    if ((color.Length == 3 || color.Length == 4) && liens[i].B.Couleur == color[2]) { yellow = false; }
                    if (color.Length == 4 && liens[i].B.Couleur == color[3]) { brown = false; }
                }
                if ((liens[i] != null) && (som == liens[i].B) && (liens[i].A.Couleur != null))
                {
                    if (liens[i].A.Couleur == color[0]) { blue = false; }
                    if (liens[i].A.Couleur == color[1]) { red = false; }
                    if ((color.Length == 3 || color.Length == 4) && liens[i].A.Couleur == color[2]) { yellow = false; }
                    if (color.Length == 4 && liens[i].A.Couleur == color[3]) { brown = false; }
                }
            }
            if (color.Length == 4) { return new bool[] { blue, red, yellow, brown }; }
            if (color.Length == 3) { return new bool[] { blue, red, yellow }; }
            return new bool[] { blue, red };
        }
        /// <summary>
        /// Effectue la coloration de chaque sommet de la figure
        /// </summary>
        /// <param name="som">Ensemble des sommets de la figure.</param>
        /// <param name="aretes">Ensemble des arêtes de la figure.</param>
        /// <param name="color">Palette de couleurs utilisées. La coloration se fera en fonction du nombre de couleurs contenues dans ce paramètre.</param>
        /// <returns>Le tableau de Sommet renvoyés contient les sommets de la figure ainsi que leur couleur.</returns>
        static Maillon[] Coloration(Maillon[] som, Lien[] liens, String[] color)
        {
            som[0].Couleur = color[0]; // Attribut une couleur au premier sommet de la figure.
            for (int i = 0; i < liens.Length; i++)
            {
                if (som[0] == liens[i].A) { liens[i].A = som[0]; }
                if (som[0] == liens[i].B) { liens[i].B = som[0]; }
            }
            if (color.Length == 2)
            {
                for (int i = 1; i < som.Length; i++)
                {
                    bool faitdeuxfois = false;
                    E: Lien[] aretessom = AretesSommet(som[i], liens);
                    bool[] col = WhichColor(som[i], aretessom, color);
                    if (col[0] == true)
                    {
                        som[i].Couleur = color[0];
                    }
                    if (col[0] == false && col[1] == true) { som[i].Couleur = color[1]; }
                    if (col[0] == false && col[1] == false && faitdeuxfois == false)
                    {
                        if (WhichColor(som[i - 1], AretesSommet(som[i - 1], liens), color)[0] == true && WhichColor(som[i - 1], AretesSommet(som[i - 1], liens), color)[1] == true)
                        {
                            if (som[i - 1] != null && som[i - 1].Couleur == color[0])
                            {
                                som[i - 1].Couleur = color[1];
                            }
                            if (som[i - 1] != null && som[i - 1].Couleur == color[1])
                            {
                                som[i - 1].Couleur = color[0];
                            }
                            for (int j = 0; j < liens.Length; j++)
                            {
                                if (som[i - 1] == liens[j].A) { liens[j].A = som[i - 1]; }
                                if (som[i - 1] == liens[j].B) { liens[j].B = som[i - 1]; }
                            }
                            faitdeuxfois = true;
                            goto E;
                        }
                    }
                    for (int j = 0; j < liens.Length; j++)
                    {
                        if (som[i] == liens[j].A) { liens[j].A = som[i]; }
                        if (som[i] == liens[j].B) { liens[j].B = som[i]; }
                    }
                }
            }
            if (color.Length == 3)
            {
                for (int i = 1; i < som.Length; i++)
                {
                    int count = 1;
                    F: Lien[] aretessom = AretesSommet(som[i], liens);
                    bool[] col = WhichColor(som[i], aretessom, color);
                    if (col[0] == true) { som[i].Couleur = color[0]; }
                    if (col[0] == false && col[1] == true) { som[i].Couleur = color[1]; }
                    if (col[0] == false && col[1] == false && col[2] == true) { som[i].Couleur = color[2]; }
                    if (col[0] == false && col[1] == false && col[2] == false && count <= 3)
                    {
                        if (WhichColor(som[i - 1], AretesSommet(som[i - 1], liens), color)[0] == true && WhichColor(som[i - 1], AretesSommet(som[i - 1], liens), color)[1] == true)
                        {
                            if (som[i - 1] != null && som[i - 1].Couleur == color[0])
                            {
                                som[i - 1].Couleur = color[1];
                            }
                            if (som[i - 1] != null && som[i - 1].Couleur == color[1])
                            {
                                som[i - 1].Couleur = color[0];
                            }
                            for (int j = 0; j < liens.Length; j++)
                            {
                                if (som[i - 1] == liens[j].A) { liens[j].A = som[i - 1]; }
                                if (som[i - 1] == liens[j].B) { liens[j].B = som[i - 1]; }
                            }
                            count++;
                            goto F;
                        }
                        else
                        {
                            if (WhichColor(som[i - 1], AretesSommet(som[i - 1], liens), color)[0] == true && WhichColor(som[i - 1], AretesSommet(som[i - 1], liens), color)[2] == true)
                            {
                                if (som[i - 1] != null && som[i - 1].Couleur == color[0])
                                {
                                    som[i - 1].Couleur = color[2];
                                }
                                if (som[i - 1] != null && som[i - 1].Couleur == color[2])
                                {
                                    som[i - 1].Couleur = color[0];
                                }
                                for (int j = 0; j < liens.Length; j++)
                                {
                                    if (som[i - 1] == liens[j].A) { liens[j].A = som[i - 1]; }
                                    if (som[i - 1] == liens[j].B) { liens[j].B = som[i - 1]; }
                                }
                                count++;
                                goto F;
                            }
                            else
                            {
                                if (WhichColor(som[i - 1], AretesSommet(som[i - 1], liens), color)[1] == true && WhichColor(som[i - 1], AretesSommet(som[i - 1], liens), color)[2] == true)
                                {
                                    if (som[i - 1] != null && som[i - 1].Couleur == color[1])
                                    {
                                        som[i - 1].Couleur = color[2];
                                    }
                                    if (som[i - 1] != null && som[i - 1].Couleur == color[2])
                                    {
                                        som[i - 1].Couleur = color[1];
                                    }
                                    for (int j = 0; j < liens.Length; j++)
                                    {
                                        if (som[i - 1] == liens[j].A) { liens[j].A = som[i - 1]; }
                                        if (som[i - 1] == liens[j].B) { liens[j].B = som[i - 1]; }
                                    }
                                    count++;
                                    goto F;
                                }
                            }
                        }
                    }
                    for (int j = 0; j < liens.Length; j++)
                    {
                        if (som[i] == liens[j].A) { liens[j].A = som[i]; }
                        if (som[i] == liens[j].B) { liens[j].B = som[i]; }
                    }
                }
            }
            if (color.Length == 4)
            {
                //System.Windows.MessageBox.Show("ici");
                for (int i = 1; i < som.Length; i++)
                {
                    int count = 1;
                    G: Lien[] aretessom = AretesSommet(som[i], liens);
                    bool[] col = WhichColor(som[i], aretessom, color);
                    if (col[0] == true) { som[i].Couleur = color[0]; }
                    if (col[0] == false && col[1] == true) { som[i].Couleur = color[1]; }
                    if (col[0] == false && col[1] == false && col[2] == true) { som[i].Couleur = color[2]; }
                    if (col[0] == false && col[1] == false && col[2] == false && col[3] == true) { som[i].Couleur = color[3]; }
                    if (col[0] == false && col[1] == false && col[2] == false && col[3] == false && count <= 7)
                    {
                        bool test1 = true;
                        bool test2 = true;
                        bool test3 = true;
                        bool test4 = true;
                        bool test5 = true;
                        bool test6 = true;
                        if (WhichColor(som[i - 1], AretesSommet(som[i - 1], liens), color)[0] == true && WhichColor(som[i - 1], AretesSommet(som[i - 1], liens), color)[1] == true && test1 == true)
                        {
                            if (som[i - 1] != null && som[i - 1].Couleur == color[0])
                            {
                                som[i - 1].Couleur = color[1];
                            }
                            if (som[i - 1] != null && som[i - 1].Couleur == color[1])
                            {
                                som[i - 1].Couleur = color[0];
                            }
                            for (int j = 0; j < liens.Length; j++)
                            {
                                if (som[i - 1] == liens[j].A) { liens[j].A = som[i - 1]; }
                                if (som[i - 1] == liens[j].B) { liens[j].B = som[i - 1]; }
                            }
                            count++;
                            test1 = false;
                            goto G;
                        }
                        else
                        {
                            if (WhichColor(som[i - 1], AretesSommet(som[i - 1], liens), color)[0] == true && WhichColor(som[i - 1], AretesSommet(som[i - 1], liens), color)[2] == true && test2 == true)
                            {
                                if (som[i - 1] != null && som[i - 1].Couleur == color[0])
                                {
                                    som[i - 1].Couleur = color[2];
                                }
                                if (som[i - 1] != null && som[i - 1].Couleur == color[2])
                                {
                                    som[i - 1].Couleur = color[0];
                                }
                                for (int j = 0; j < liens.Length; j++)
                                {
                                    if (som[i - 1] == liens[j].A) { liens[j].A = som[i - 1]; }
                                    if (som[i - 1] == liens[j].B) { liens[j].B = som[i - 1]; }
                                }
                                count++;
                                test2 = false;
                                goto G;
                            }
                            else
                            {
                                if (WhichColor(som[i - 1], AretesSommet(som[i - 1], liens), color)[0] == true && WhichColor(som[i - 1], AretesSommet(som[i - 1], liens), color)[3] == true && test3 == true)
                                {
                                    if (som[i - 1] != null && som[i - 1].Couleur == color[0])
                                    {
                                        som[i - 1].Couleur = color[3];
                                    }
                                    if (som[i - 1] != null && som[i - 1].Couleur == color[3])
                                    {
                                        som[i - 1].Couleur = color[0];
                                    }
                                    for (int j = 0; j < liens.Length; j++)
                                    {
                                        if (som[i - 1] == liens[j].A) { liens[j].A = som[i - 1]; }
                                        if (som[i - 1] == liens[j].B) { liens[j].B = som[i - 1]; }
                                    }
                                    count++;
                                    test3 = false;
                                    goto G;
                                }
                                else
                                {
                                    if (WhichColor(som[i - 1], AretesSommet(som[i - 1], liens), color)[1] == true && WhichColor(som[i - 1], AretesSommet(som[i - 1], liens), color)[2] == true && test4 == true)
                                    {
                                        if (som[i - 1] != null && som[i - 1].Couleur == color[1])
                                        {
                                            som[i - 1].Couleur = color[2];
                                        }
                                        if (som[i - 1] != null && som[i - 1].Couleur == color[2])
                                        {
                                            som[i - 1].Couleur = color[1];
                                        }
                                        for (int j = 0; j < liens.Length; j++)
                                        {
                                            if (som[i - 1] == liens[j].A) { liens[j].A = som[i - 1]; }
                                            if (som[i - 1] == liens[j].B) { liens[j].B = som[i - 1]; }
                                        }
                                        count++;
                                        test4 = false;
                                        goto G;
                                    }
                                    else
                                    {
                                        if (WhichColor(som[i - 1], AretesSommet(som[i - 1], liens), color)[1] == true && WhichColor(som[i - 1], AretesSommet(som[i - 1], liens), color)[3] == true && test5 == true)
                                        {
                                            if (som[i - 1] != null && som[i - 1].Couleur == color[1])
                                            {
                                                som[i - 1].Couleur = color[3];
                                            }
                                            if (som[i - 1] != null && som[i - 1].Couleur == color[3])
                                            {
                                                som[i - 1].Couleur = color[1];
                                            }
                                            for (int j = 0; j < liens.Length; j++)
                                            {
                                                if (som[i - 1] == liens[j].A) { liens[j].A = som[i - 1]; }
                                                if (som[i - 1] == liens[j].B) { liens[j].B = som[i - 1]; }
                                            }
                                            count++;
                                            test5 = false;
                                            goto G;
                                        }
                                        else
                                        {
                                            if (WhichColor(som[i - 1], AretesSommet(som[i - 1], liens), color)[2] == true && WhichColor(som[i - 1], AretesSommet(som[i - 1], liens), color)[3] == true && test6 == true)
                                            {
                                                if (som[i - 1] != null && som[i - 1].Couleur == color[2])
                                                {
                                                    som[i - 1].Couleur = color[3];
                                                }
                                                if (som[i - 1] != null && som[i - 1].Couleur == color[3])
                                                {
                                                    som[i - 1].Couleur = color[2];
                                                }
                                                for (int j = 0; j < liens.Length; j++)
                                                {
                                                    if (som[i - 1] == liens[j].A) { liens[j].A = som[i - 1]; }
                                                    if (som[i - 1] == liens[j].B) { liens[j].B = som[i - 1]; }
                                                }
                                                count++;
                                                test6 = false;
                                                goto G;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    for (int j = 0; j < liens.Length; j++)
                    {
                        if (som[i] == liens[j].A) { liens[j].A = som[i]; }
                        if (som[i] == liens[j].B) { liens[j].B = som[i]; }
                    }
                }
            }
            return som;
        }
        public static List<Maillon> Solveur(int nbMaillon, string[] tabCouleur, Lien[] link)
        {
            #region Exercice1
            Maillon[] som = new Maillon[nbMaillon];
            for (int i = 0; i < nbMaillon; i++)
            {
                Maillon A = new Maillon();
                som[i] = A;
            }

            Maillon[] res = Coloration(som, link, tabCouleur);
            List<Maillon> lstmaillon = new List<Maillon>();
            foreach (Maillon so in res)
            {
                lstmaillon.Add(so);
            }

            return lstmaillon;
            #endregion
        }
    }
}
