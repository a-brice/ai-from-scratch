﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfInfoFonda
{
    /// <summary>
    /// Logique d'interaction pour Verificateur.xaml
    /// </summary>
    public partial class Verificateur : Window
    {
        public Verificateur()
        {
            InitializeComponent();
        }


        List<ComboBox> lstcombobox = new List<ComboBox>();



        public void AjoutSommet(int nbSommet)
        {
            lstcombobox.Clear();
            for (int i = 1; i < nbSommet + 1; i++)
            {

                DockPanel dc = new DockPanel() { Margin = new Thickness(0, 10, 0, 10), Name = "dck" + i };
                Label l = new Label() { Name = $"lbl{i}", Content = $"Sommet n°{i} : " };
                ComboBox cb = new ComboBox() { Name = $"cbb1{i}", Height = 20, Width = 100 };
                cb.Items.Add("Rouge"); cb.Items.Add("Violet"); cb.Items.Add("Vert");
                lstcombobox.Add(cb);
                dc.Children.Add(l);
                dc.Children.Add(cb);
                stkpanel.Children.Add(dc);
            }

        }

        public Lien[] saveLink()
        {
            Lien[] lienUtilisateur = null;
            if (textboxlink.Text != null && textboxlink.Text.Length > 2 && !textboxlink.Text.Contains("<=>"))
            {
                int idmax = 0;
                string[] sep = { ";", Environment.NewLine };
                string[] link = textboxlink.Text.Split(sep, StringSplitOptions.RemoveEmptyEntries);
                List<Lien> lstlien = new List<Lien>();
                Array.ForEach(link, x => {
                    int.TryParse(x.Split('-')[0], out int m1);
                    int.TryParse(x.Split('-')[1], out int m2);
                    if (m1 > 0 && m2 > 0)
                    {
                        if (m1 > idmax) idmax = m1;
                        if (m2 > idmax) idmax = m2;

                        Lien l = new Lien(new Maillon(m1), new Maillon(m2));
                        lstlien.Add(l);
                    }
                });
                lienUtilisateur = lstlien.ToArray();
                AjoutSommet(idmax);     // Permet a l'utilisateur d'entrer les differente couleur des maillons
            }
            return lienUtilisateur;
        }
        public Lien[] lien;
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            stkpanel.Children.Clear();

            lien = saveLink();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            bool verif = true;
            List<Maillon> lstmaillon = new List<Maillon>();

            if (lien != null && lstcombobox != null)
            {


                lstcombobox.ForEach(cbb => {if (cbb.SelectedValue != null)
                        lstmaillon.Add(new Maillon( cbb.SelectedValue.ToString() )); }
                        );
                

                foreach (Lien item in lien)
                {
                    Maillon m1 = lstmaillon.Find(x => x.Id == item.A.Id);
                    Maillon m2 = lstmaillon.Find(x => x.Id == item.B.Id);
                    if (m1 is null || m2 is null || m1.Couleur == m2.Couleur) verif = false;
                }
            }
            string msg = verif ? "Le Shéma entré en paramètre est correct !" : "Le shéma entré en paramètre est incorrect !";
            MessageBox.Show(msg);
            Maillon.Cpt = 0;

            // Afficher la solution
            Dictionary<int, List<Maillon>> dico = new Dictionary<int, List<Maillon>>();
            dico.Add(0, lstmaillon);
            new Search(dico, lien, DateTime.Now, 0).Show();
        }
    }
}
