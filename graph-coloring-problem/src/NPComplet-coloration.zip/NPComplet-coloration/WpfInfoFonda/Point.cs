﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Forms;
using System.Drawing;



namespace WpfInfoFonda
{
    public class Point
    {
        double x;
        double y;
        public double X { get { return x; } } public double Y { get { return y; } }
        public Point(double x, double y)
        {
            this.x = x;
            this.y = y;
        }
        public Point() { }

        public static bool DistanceSuffisante(Point a, Point b)
        {
            bool suf = true;
            if (Math.Sqrt((b.Y - a.Y)* (b.Y - a.Y) + (b.X - a.X)* (b.X - a.X)) < 100) suf = false;
            return suf;
        }
    }
}
